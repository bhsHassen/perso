package com.grokonez.jwtauthentication.servcicesImpl;

import java.util.List;
import java.util.Optional;
import java.util.Set;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.grokonez.jwtauthentication.model.Device;
import com.grokonez.jwtauthentication.model.Espace;
import com.grokonez.jwtauthentication.model.NotFoundException;
import com.grokonez.jwtauthentication.model.Zone;
import com.grokonez.jwtauthentication.repository.DeviceRepository;
import com.grokonez.jwtauthentication.repository.EspaceRepository;
import com.grokonez.jwtauthentication.servcices.IDeviceService;

@Service("deviceService")

public class DeviceServiceImpl implements IDeviceService {
	
	@Autowired
	private DeviceRepository deviceRepository;
	
	
	
	@Autowired
	private EspaceRepository espaceRepository;

	@Override
	public Device addDevice(Long spaceId, @Valid Device device) {
		return espaceRepository.findById(spaceId).map(space -> {
			device.setEspace(space);;
			device.setSapce_name(space.getNom());
            return deviceRepository.save(device);
        }).orElseThrow(() -> new NotFoundException("zone not found!"));
	}

	@Override
	public List<Device> getListedeviceyUser(Long userId) {
		return deviceRepository.findByUserid(userId);
	}

	@Override
	public Set<Device> getListDevicebySpaceId(Long spaceId) {
		Optional<Espace> optSpace = espaceRepository.findById(spaceId);
		if(optSpace.isPresent()) {
    		Espace e = optSpace.get();
    		return e.getDevices();
    	}else {
    		throw new NotFoundException("space not found with id " + spaceId);
    	}
	}

	@Override
	public Device updatedevice(Long deviceId, @Valid Device deviceUpdated) {
		  return deviceRepository.findById(deviceId)
	                .map(device -> {
	                	device.setNom(deviceUpdated.getNom());
	                	device.setDescription(deviceUpdated.getDescription());
	                	device.setDate_modif(deviceUpdated.getDate_modif());
	                	device.setType_device(deviceUpdated.getType_device());
	                    return deviceRepository.save(device);
	                }).orElseThrow(() -> new NotFoundException("device  not found!"));
	}

	@Override
	public String deleteDevice(Long deviceId) {
		Optional<Device> optdevice = deviceRepository.findById(deviceId);
		if(optdevice.isPresent()) 
		{
			Device a = optdevice.get();
			deviceRepository.delete(a);
        	return "200";
        	
			
		}
		else return "500";
	}

	@Override
	public Device getDeviceById(Long deviceId) {
		Optional<Device> opt = deviceRepository.findById(deviceId);
    	if(opt.isPresent()) {
    		return opt.get();
    	}else {
    		throw new NotFoundException("device not found with id " + deviceId);
    	}
	}

	


}
