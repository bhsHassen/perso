package com.grokonez.jwtauthentication.servcicesImpl;

import java.util.List;
import java.util.Optional;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.grokonez.jwtauthentication.model.Espace;
import com.grokonez.jwtauthentication.model.NotFoundException;
import com.grokonez.jwtauthentication.model.Zone;
import com.grokonez.jwtauthentication.repository.UserRepository;
import com.grokonez.jwtauthentication.repository.ZoneRepository;
import com.grokonez.jwtauthentication.servcices.IZoneService;





@Service("zoneService")
public class ZoneServiceImpl implements IZoneService {
	
	@Autowired
	private ZoneRepository zoneRepository;
	
	@Autowired
	private UserRepository userRepository;

	@Override
	public List<Zone> getListZonebyUser(Long userId) {
		 if(!userRepository.existsById(userId)) {
	            throw new NotFoundException("user not found!");
	        }
	    	
	    	return zoneRepository.findByuserId(userId);
	}

	@Override
	public Zone addZone(Long userId, Zone zone) {
		   return userRepository.findById(userId)
	                .map(user -> {
	                    zone.setUser(user);
	                    return zoneRepository.save(zone);
	                }).orElseThrow(() -> new NotFoundException("zone not found!"));
	}

	@Override
	public Zone getZoneByid(Long zoneId) {
		Optional<Zone> optZone = zoneRepository.findById(zoneId);
    	if(optZone.isPresent()) {
    		return optZone.get();
    	}else {
    		throw new NotFoundException("Zone not found with id " + zoneId);
    	}
	}

	@Override
	public Zone updateZone(Long zoneId, @Valid Zone zoneUpdated) {
		  return zoneRepository.findById(zoneId)
	                .map(zone -> {
	                  zone.setNom(zoneUpdated.getNom());
	                  zone.setGouvernorat(zoneUpdated.getGouvernorat());
	                  zone.setDescription(zoneUpdated.getDescription());
	                  zone.setDate_modif(zoneUpdated.getDate_modif());
	                    return zoneRepository.save(zone);
	                }).orElseThrow(() -> new NotFoundException("zone  not found!"));
	}

	@Override
	public String deletesZone(Long zoneId) {
		Optional<Zone> optpzone = zoneRepository.findById(zoneId);
		if(optpzone.isPresent()) 
		{
			Zone a = optpzone.get();
			zoneRepository.delete(a);
        	return "200";
        	
			
		}
		else return "500";
	}
	

}
