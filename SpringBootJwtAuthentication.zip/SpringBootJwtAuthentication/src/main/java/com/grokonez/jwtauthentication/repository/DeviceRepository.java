package com.grokonez.jwtauthentication.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.grokonez.jwtauthentication.model.Device;

public interface DeviceRepository extends JpaRepository<Device, Long> {
	List<Device> findByUserid(Long userId);


}
