package com.grokonez.jwtauthentication.model;

import java.io.Serializable;
import java.util.Date;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Transient;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@Entity
@Table(name = "espaces")
@JsonIgnoreProperties({ "hibernateLazyInitializer", "handler" })
public class Espace implements Serializable {
	private static final long serialVersionUID = 1L;

	public Espace(Long id, String nom, String description, Date date_ajout, Date date_modif, Long userid,
			String zonename, Zone zone) {
		super();
		this.id = id;
		this.nom = nom;
		this.description = description;
		this.date_ajout = date_ajout;
		this.date_modif = date_modif;
		this.userid = userid;
		this.zonename = zonename;
		this.zone = zone;
	}

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;

	@Column(name = "nom")
	private String nom;

	@Column(name = "description")
	private String description;

	@Column(name = "date_ajout")
	private Date date_ajout;

	@Column(name = "date_modif")
	private Date date_modif;

	@Column(name = "userid")
	private Long userid;

	@Column(name = "zonename")
	private String zonename;

	@ManyToOne(fetch = FetchType.LAZY, optional = false)
	@JoinColumn(name = "zone_id", nullable = false)
	@JsonIgnore
	private Zone zone;
	
	@OneToMany(mappedBy = "espace", cascade = CascadeType.ALL, fetch = FetchType.LAZY)
    private Set<Device> devices;

	public Espace() {
	}
	
	

	public Espace(Long id, String nom, String description, Date date_ajout, Date date_modif, Long userid,
			String zonename, Zone zone, Set<Device> devices) {
		super();
		this.id = id;
		this.nom = nom;
		this.description = description;
		this.date_ajout = date_ajout;
		this.date_modif = date_modif;
		this.userid = userid;
		this.zonename = zonename;
		this.zone = zone;
		this.devices = devices;
	}



	public Set<Device> getDevices() {
		return devices;
	}



	public void setDevices(Set<Device> devices) {
		this.devices = devices;
	}



	public String getZonename() {
		return zonename;
	}

	public void setZonename(String zonename) {
		this.zonename = zonename;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getNom() {
		return nom;
	}

	public void setNom(String nom) {
		this.nom = nom;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public Date getDate_ajout() {
		return date_ajout;
	}

	public void setDate_ajout(Date date_ajout) {
		this.date_ajout = date_ajout;
	}

	public Date getDate_modif() {
		return date_modif;
	}

	public void setDate_modif(Date date_modif) {
		this.date_modif = date_modif;
	}

	public Long getUserid() {
		return userid;
	}

	public void setUserid(Long userid) {
		this.userid = userid;
	}

	public Zone getZone() {
		return zone;
	}

	public void setZone(Zone zone) {
		this.zone = zone;
	}

}
