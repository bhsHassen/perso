package com.grokonez.jwtauthentication.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.grokonez.jwtauthentication.model.Zone;

public interface ZoneRepository extends JpaRepository<Zone, Long>{
	
	List<Zone> findByuserId(Long userId);	


}
