package com.grokonez.jwtauthentication.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.grokonez.jwtauthentication.model.Espace;

public interface EspaceRepository extends JpaRepository<Espace,Long> {
	
	
	  @Query("select u from Espace u where u.userid=:userid ORDER BY u.date_ajout ASC")
		public List<Espace> findByUserid(@Param("userid") Long userid);
	  
	  @Query("select count(u) from Espace u where u.userid=:userid ")
		public long getcountspaces(@Param("userid") Long userid);
	  
	  

}
