package com.grokonez.jwtauthentication.servcices;

import java.util.List;

import javax.validation.Valid;

import com.grokonez.jwtauthentication.model.Zone;

public interface IZoneService {
	
	 public List<Zone> getListZonebyUser(Long userId);
	 
	 public Zone addZone( Long userId,Zone zone);
	 
	 public Zone getZoneByid( Long zoneId);

	public Zone updateZone(Long zoneId, @Valid Zone zoneUpdated);

	public String deletesZone(Long zoneId);


}
