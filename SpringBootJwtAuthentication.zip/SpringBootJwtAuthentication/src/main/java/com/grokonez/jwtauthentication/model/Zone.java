package com.grokonez.jwtauthentication.model;

import java.io.Serializable;
import java.util.Date;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@Entity
@Table(name = "zones")
@JsonIgnoreProperties({"hibernateLazyInitializer", "handler"})
public class Zone implements Serializable {
	private static final long serialVersionUID = 1L;

	
	@Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;
	
	
	@Column(name = "nom")
	private String nom;
	
	@Column(name = "description")
	private String description ;
	
	@Column(name = "gouvernorat")
	private String gouvernorat ;
	
	@Column(name = "date_ajout")
	private Date date_ajout ;
	
	@Column(name = "date_modif")
	private Date date_modif ;
	
	@ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "user_id", nullable = false)
    @JsonIgnore
    private User user;
	
	
	
	
	@OneToMany(mappedBy = "zone", cascade = CascadeType.ALL, fetch = FetchType.LAZY)
	    private Set<Espace> espaces;
	


	

	public Zone(Long id, String nom, String description, String gouvernorat, Date date_ajout, Date date_modif,
			User user, Set<Espace> espaces) {
		super();
		this.id = id;
		this.nom = nom;
		this.description = description;
		this.gouvernorat = gouvernorat;
		this.date_ajout = date_ajout;
		this.date_modif = date_modif;
		this.user = user;
		this.espaces = espaces;
	}

	public Zone() {}


	public Set<Espace> getEspaces() {
		return espaces;
	}



	public void setEspaces(Set<Espace> espaces) {
		this.espaces = espaces;
	}



	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getNom() {
		return nom;
	}

	public void setNom(String nom) {
		this.nom = nom;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getGouvernorat() {
		return gouvernorat;
	}

	public void setGouvernorat(String gouvernorat) {
		this.gouvernorat = gouvernorat;
	}

	public Date getDate_ajout() {
		return date_ajout;
	}

	public void setDate_ajout(Date date_ajout) {
		this.date_ajout = date_ajout;
	}

	public Date getDate_modif() {
		return date_modif;
	}

	public void setDate_modif(Date date_modif) {
		this.date_modif = date_modif;
	}

	public User getUser() {
		return user;
	}

	public void setUser(User user) {
		this.user = user;
	}
	
	
	

}
