package com.grokonez.jwtauthentication.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.grokonez.jwtauthentication.model.Marque_Model;

public interface Marque_modelRepository extends JpaRepository<Marque_Model, Long> {

}
