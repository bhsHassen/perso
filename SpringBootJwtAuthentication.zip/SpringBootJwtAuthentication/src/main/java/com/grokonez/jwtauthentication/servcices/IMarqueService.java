package com.grokonez.jwtauthentication.servcices;

public interface IMarqueService {

}
