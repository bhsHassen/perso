package com.grokonez.jwtauthentication.servcices;

public class IMarque_modelService {

}
