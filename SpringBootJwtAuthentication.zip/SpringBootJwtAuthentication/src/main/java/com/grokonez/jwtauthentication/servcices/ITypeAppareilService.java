package com.grokonez.jwtauthentication.servcices;

import java.util.List;

import javax.validation.Valid;

import com.grokonez.jwtauthentication.model.TypeAppareil;

public interface ITypeAppareilService {

	TypeAppareil addTypeAppareil(@Valid TypeAppareil typeAppareil);

	List<TypeAppareil> getListTypeAppareil(Long userId);

	String deleteTypeAppareil(Long typeId);
	

}
