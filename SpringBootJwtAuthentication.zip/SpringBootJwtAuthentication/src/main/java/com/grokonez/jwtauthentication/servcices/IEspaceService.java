package com.grokonez.jwtauthentication.servcices;

import java.util.List;
import java.util.Set;

import javax.validation.Valid;

import com.grokonez.jwtauthentication.model.Espace;

public interface IEspaceService {
	
	
	 public Espace addEspace( Long userId,Espace espace);

	public List<Espace> getListespacebyUser(Long userId);

	public Set<Espace> getListEspacebyZoneId(Long zoneId);

	public String deletespace( Long espaceId);

	public Espace updateEspace(Long espaceId, @Valid Espace espaceUpdated);

	public Espace getEspaceById(Long espaceId);

	public Long getnbrEspace(Long userid);


}
