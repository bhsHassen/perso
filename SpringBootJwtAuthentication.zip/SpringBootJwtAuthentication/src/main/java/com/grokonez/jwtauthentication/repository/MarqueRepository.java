package com.grokonez.jwtauthentication.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.grokonez.jwtauthentication.model.Marque;

public interface MarqueRepository extends JpaRepository<Marque, Long>  {

}
