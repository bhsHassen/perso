package com.grokonez.jwtauthentication.servcices;

import java.util.List;
import java.util.Set;

import javax.validation.Valid;

import com.grokonez.jwtauthentication.model.Device;
import com.grokonez.jwtauthentication.model.Espace;

public interface IDeviceService {

	Device addDevice(Long spaceId, @Valid Device device);

	List<Device> getListedeviceyUser(Long userId);

	Set<Device> getListDevicebySpaceId(Long spaceId);

	Device updatedevice(Long deviceId, @Valid Device deviceUpdated);

	String deleteDevice(Long deviceId);

	Device getDeviceById(Long deviceId);
	

}
