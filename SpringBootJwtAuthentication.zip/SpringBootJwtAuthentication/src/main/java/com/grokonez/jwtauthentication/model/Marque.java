package com.grokonez.jwtauthentication.model;

import java.io.Serializable;
import java.util.Date;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(name = "marques")
public class Marque implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;

	@Column(name = "nom")
	private String nom;

	@Column(name = "description")
	private String description;

	@Column(name = "date_ajout")
	private Date date_ajout;

	@Column(name = "date_modif")
	private Date date_modif;

	@OneToMany(mappedBy = "marque", cascade = CascadeType.ALL, fetch = FetchType.LAZY)
	private Set<Marque_Model> marque_model;

	public Marque() {
	}

	public Marque(Long id, String nom, String description, Date date_ajout, Date date_modif,
			Set<Marque_Model> marque_model) {
		super();
		this.id = id;
		this.nom = nom;
		this.description = description;
		this.date_ajout = date_ajout;
		this.date_modif = date_modif;
		this.marque_model = marque_model;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getNom() {
		return nom;
	}

	public void setNom(String nom) {
		this.nom = nom;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public Date getDate_ajout() {
		return date_ajout;
	}

	public void setDate_ajout(Date date_ajout) {
		this.date_ajout = date_ajout;
	}

	public Date getDate_modif() {
		return date_modif;
	}

	public void setDate_modif(Date date_modif) {
		this.date_modif = date_modif;
	}

	public Set<Marque_Model> getMarque_model() {
		return marque_model;
	}

	public void setMarque_model(Set<Marque_Model> marque_model) {
		this.marque_model = marque_model;
	}

}
