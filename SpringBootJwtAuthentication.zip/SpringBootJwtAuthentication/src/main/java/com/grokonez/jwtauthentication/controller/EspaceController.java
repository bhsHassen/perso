package com.grokonez.jwtauthentication.controller;

import java.util.List;
import java.util.Set;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.grokonez.jwtauthentication.model.Espace;
import com.grokonez.jwtauthentication.model.NotFoundException;
import com.grokonez.jwtauthentication.model.Zone;
import com.grokonez.jwtauthentication.servcices.IEspaceService;

@CrossOrigin(origins = "*")
@RestController
@RequestMapping("/api/espaces")
public class EspaceController {

	@Autowired
	@Qualifier("espaceService")
	private IEspaceService espaceservice;

	@PostMapping("/{zoneID}")
	public Espace addEspace(@PathVariable Long zoneID, @Valid @RequestBody Espace espace) {
		return espaceservice.addEspace(zoneID, espace);
	}

	@GetMapping("/{userId}")
	public List<Espace> getListEspacebyUser(@PathVariable Long userId) {
		return espaceservice.getListespacebyUser(userId);
	}

	@GetMapping("/getbyzoneid/{zoneId}")
	public Set<Espace> getListEspacebyZoneId(@PathVariable Long zoneId) {
		return espaceservice.getListEspacebyZoneId(zoneId);
	}

	@GetMapping("/deleteEspace/{espaceId}")
	public String deletespace(@PathVariable Long espaceId) {

		return espaceservice.deletespace(espaceId);

	}
	
	
	 @PutMapping("/updateEspace/{espaceId}")
	    public Espace updateEspace(@PathVariable Long espaceId,
	    								
	    								@Valid @RequestBody Espace EspaceUpdated) {
		 
			return espaceservice.updateEspace(espaceId,EspaceUpdated);	    	
	    	
	    }
	 
	 @GetMapping("getEspace/{espaceId}")
		public Espace getEspaceById(@PathVariable Long espaceId) {
		     return	espaceservice.getEspaceById(espaceId);
		}
	 
	 @GetMapping("getnbrEspace/{userid}")
		public Long getnbrEspace(@PathVariable Long  userid) {
		     return	espaceservice.getnbrEspace(userid);
		}
	
	
	
}
