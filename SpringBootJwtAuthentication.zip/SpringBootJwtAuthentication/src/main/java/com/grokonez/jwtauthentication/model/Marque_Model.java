package com.grokonez.jwtauthentication.model;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@Entity
@Table(name = "marque_models")
@JsonIgnoreProperties({ "hibernateLazyInitializer", "handler" })
public class Marque_Model implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;

	@Column(name = "nom")
	private String nom;

	@Column(name = "description")
	private String description;

	@Column(name = "puissance")
	private double puissance;

	@Column(name = "voltage")
	private double voltage;

	@Column(name = "max_amperage")
	private double max_amperage;

	@Column(name = "frequence")
	private double frequence;

	@Column(name = "energie")
	private double energie;

	@Column(name = "date_ajout")
	private Date date_ajout;

	@Column(name = "date_modif")
	private Date date_modif;

	@ManyToOne(fetch = FetchType.LAZY, optional = false)
	@JoinColumn(name = "marque_id", nullable = false)
	@JsonIgnore
	private Marque marque;

	public Marque_Model() {

	}

	public Marque_Model(Long id, String nom, String description, double puissance, double voltage, double max_amperage,
			double frequence, double energie, Date date_ajout, Date date_modif, Marque marque) {
		super();
		this.id = id;
		this.nom = nom;
		this.description = description;
		this.puissance = puissance;
		this.voltage = voltage;
		this.max_amperage = max_amperage;
		this.frequence = frequence;
		this.energie = energie;
		this.date_ajout = date_ajout;
		this.date_modif = date_modif;
		this.marque = marque;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getNom() {
		return nom;
	}

	public void setNom(String nom) {
		this.nom = nom;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public double getPuissance() {
		return puissance;
	}

	public void setPuissance(double puissance) {
		this.puissance = puissance;
	}

	public double getVoltage() {
		return voltage;
	}

	public void setVoltage(double voltage) {
		this.voltage = voltage;
	}

	public double getMax_amperage() {
		return max_amperage;
	}

	public void setMax_amperage(double max_amperage) {
		this.max_amperage = max_amperage;
	}

	public double getFrequence() {
		return frequence;
	}

	public void setFrequence(double frequence) {
		this.frequence = frequence;
	}

	public double getEnergie() {
		return energie;
	}

	public void setEnergie(double energie) {
		this.energie = energie;
	}

	public Date getDate_ajout() {
		return date_ajout;
	}

	public void setDate_ajout(Date date_ajout) {
		this.date_ajout = date_ajout;
	}

	public Date getDate_modif() {
		return date_modif;
	}

	public void setDate_modif(Date date_modif) {
		this.date_modif = date_modif;
	}

	public Marque getMarque() {
		return marque;
	}

	public void setMarque(Marque marque) {
		this.marque = marque;
	}

}
