package com.grokonez.jwtauthentication.servcicesImpl;

import java.util.List;
import java.util.Optional;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.grokonez.jwtauthentication.model.TypeAppareil;
import com.grokonez.jwtauthentication.model.TypeDevice;
import com.grokonez.jwtauthentication.repository.TypeAppareilRepository;
import com.grokonez.jwtauthentication.servcices.ITypeAppareilService;

@Service("typeAppareilService")

public class TypeAppareilServiceImpl  implements  ITypeAppareilService{
	
	@Autowired
	private TypeAppareilRepository typeAppareilRepository;

	@Override
	public TypeAppareil addTypeAppareil(@Valid TypeAppareil typeAppareil) {
		return typeAppareilRepository.save(typeAppareil);
	}

	@Override
	public List<TypeAppareil> getListTypeAppareil(Long userId) {
		// TODO Auto-generated method stub
		return typeAppareilRepository.findByUserid(userId);
	}

	@Override
	public String deleteTypeAppareil(Long typeId) {
		Optional<TypeAppareil> opttype = typeAppareilRepository.findById(typeId);
		if(opttype.isPresent()) 
		{
			TypeAppareil a = opttype.get();
			typeAppareilRepository.delete(a);
        	return "200";
        	
			
		}
		else return "500";
	}
	

}
