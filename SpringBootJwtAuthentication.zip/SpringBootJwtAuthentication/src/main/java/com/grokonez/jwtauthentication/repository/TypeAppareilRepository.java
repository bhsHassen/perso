package com.grokonez.jwtauthentication.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.grokonez.jwtauthentication.model.TypeAppareil;

public interface TypeAppareilRepository extends JpaRepository<TypeAppareil, Long> {
	
	List<TypeAppareil> findByUserid(Long userId);	


}
