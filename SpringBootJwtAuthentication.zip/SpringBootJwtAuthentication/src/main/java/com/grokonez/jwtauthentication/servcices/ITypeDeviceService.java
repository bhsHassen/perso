package com.grokonez.jwtauthentication.servcices;

import java.util.List;

import javax.validation.Valid;

import com.grokonez.jwtauthentication.model.TypeDevice;

public interface ITypeDeviceService {

	TypeDevice addTypedevice(@Valid TypeDevice typeDevice);

	List<TypeDevice> getListTypedevice(Long userId);

	String deletetypeDevice(Long typeId);

}
