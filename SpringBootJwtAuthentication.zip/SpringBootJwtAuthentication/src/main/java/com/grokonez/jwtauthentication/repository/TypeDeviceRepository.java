package com.grokonez.jwtauthentication.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.grokonez.jwtauthentication.model.TypeDevice;
import com.grokonez.jwtauthentication.model.Zone;

public interface TypeDeviceRepository extends JpaRepository<TypeDevice, Long> {
	
	List<TypeDevice> findByUserid(Long userId);	


}
