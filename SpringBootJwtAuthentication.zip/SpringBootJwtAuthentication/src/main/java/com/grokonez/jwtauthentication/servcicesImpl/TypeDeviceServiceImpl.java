package com.grokonez.jwtauthentication.servcicesImpl;

import java.util.List;
import java.util.Optional;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.grokonez.jwtauthentication.model.Device;
import com.grokonez.jwtauthentication.model.TypeDevice;
import com.grokonez.jwtauthentication.repository.TypeDeviceRepository;
import com.grokonez.jwtauthentication.servcices.ITypeDeviceService;

@Service("typeDeviceService")

public class TypeDeviceServiceImpl implements ITypeDeviceService {
	
	@Autowired
	private TypeDeviceRepository typeDeviceRepository;

	@Override
	public TypeDevice addTypedevice(@Valid TypeDevice typeDevice) {
		return typeDeviceRepository.save(typeDevice);
	}

	@Override
	public List<TypeDevice> getListTypedevice(Long userId) {
		return typeDeviceRepository.findByUserid(userId);
	}

	@Override
	public String deletetypeDevice(Long typeId) {
		Optional<TypeDevice> opttype = typeDeviceRepository.findById(typeId);
		if(opttype.isPresent()) 
		{
			TypeDevice a = opttype.get();
			typeDeviceRepository.delete(a);
        	return "200";
        	
			
		}
		else return "500";
	}

}
