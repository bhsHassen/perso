package com.grokonez.jwtauthentication.controller;

import java.util.List;
import java.util.Set;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.grokonez.jwtauthentication.model.Device;
import com.grokonez.jwtauthentication.model.Espace;
import com.grokonez.jwtauthentication.servcices.IDeviceService;

@CrossOrigin(origins = "*")
@RestController
@RequestMapping("/api/devices")
public class DeviceController {
	
	@Autowired
	@Qualifier("deviceService")
	private IDeviceService deviceService;


	@PostMapping("/{spaceId}")
	public Device addEspace(@PathVariable Long spaceId, @Valid @RequestBody Device device) {
		return deviceService.addDevice(spaceId, device);
	}
	
	@GetMapping("/{userId}")
	public List<Device> getListDevicebyUser(@PathVariable Long userId) {
		return deviceService.getListedeviceyUser(userId);
	}
	
	
	 @PutMapping("/updatedevice/{deviceId}")
	    public Device updateDevice(@PathVariable Long deviceId,
	    								
	    								@Valid @RequestBody Device deviceUpdated) {
		 
			return deviceService.updatedevice(deviceId,deviceUpdated);	    	
	    	
	    }
	
	@GetMapping("/getbySpaceid/{spaceId}")
	public Set<Device> getListDevicebyZoneId(@PathVariable Long spaceId) {
		return deviceService.getListDevicebySpaceId(spaceId);
	}
	
	@GetMapping("/deleteDevice/{deviceId}")
	public String deleteDevice(@PathVariable Long deviceId) {

		return deviceService.deleteDevice(deviceId);

	}
	
	@GetMapping("getDevice/{deviceId}")
	public Device getDeviceById(@PathVariable Long deviceId) {
	     return	deviceService.getDeviceById(deviceId);
	}



}
