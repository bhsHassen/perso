package com.grokonez.jwtauthentication.controller;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.grokonez.jwtauthentication.model.TypeAppareil;
import com.grokonez.jwtauthentication.servcices.ITypeAppareilService;

@CrossOrigin(origins = "*")
@RestController
@RequestMapping("/api/TypeAppareil")
public class TypeAppareilController {
	
	@Autowired
	@Qualifier("typeAppareilService")
	private ITypeAppareilService typeAppareilService;
	
	
	@PostMapping("/addTypeAppareil")
	public TypeAppareil addTypeAppareil( @Valid @RequestBody TypeAppareil typeAppareil) {
		return typeAppareilService.addTypeAppareil(typeAppareil);
	}
	
	@GetMapping("/getTypeAppareilList/{userId}")
	public List<TypeAppareil> getListTypeAppareil(@PathVariable Long userId) {
		return typeAppareilService.getListTypeAppareil(userId);
	}
	
	@GetMapping("/deleteTypeAppareil/{typeId}")
	public String deleteTypeAppareil(@PathVariable Long typeId) {

		return typeAppareilService.deleteTypeAppareil(typeId);

	}

}
