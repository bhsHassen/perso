package com.grokonez.jwtauthentication.controller;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.grokonez.jwtauthentication.model.Device;
import com.grokonez.jwtauthentication.model.Espace;
import com.grokonez.jwtauthentication.model.TypeDevice;
import com.grokonez.jwtauthentication.servcices.ITypeDeviceService;

@CrossOrigin(origins = "*")
@RestController
@RequestMapping("/api/TypeDevice")
public class TypeDeviceController {
	
	@Autowired
	@Qualifier("typeDeviceService")
	private ITypeDeviceService typeDeviceService;

	
	@PostMapping("/addTypeDevice")
	public TypeDevice addTypedevice( @Valid @RequestBody TypeDevice typeDevice) {
		return typeDeviceService.addTypedevice(typeDevice);
	}
	
	
	@GetMapping("/typeDeviceList/{userId}")
	public List<TypeDevice> getListTypedevice(@PathVariable Long userId) {
		return typeDeviceService.getListTypedevice(userId);
	}
	
	@GetMapping("/deleteTypeDevice/{typeId}")
	public String deleteDevice(@PathVariable Long typeId) {

		return typeDeviceService.deletetypeDevice(typeId);

	}
}
