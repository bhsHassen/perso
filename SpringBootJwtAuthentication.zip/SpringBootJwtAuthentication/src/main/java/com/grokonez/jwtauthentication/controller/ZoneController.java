package com.grokonez.jwtauthentication.controller;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.grokonez.jwtauthentication.model.Espace;
import com.grokonez.jwtauthentication.model.Zone;
import com.grokonez.jwtauthentication.servcices.IZoneService;

@CrossOrigin(origins = "*")
@RestController
@RequestMapping("/api/zones")
public class ZoneController {

	@Autowired
	@Qualifier("zoneService")
	private IZoneService zoneservice;

	@GetMapping("/{userId}")
	public List<Zone> getListZonebyUser(@PathVariable Long userId) {
		return zoneservice.getListZonebyUser(userId);
	}

	@PostMapping("/{userId}")
	public Zone addZone(@PathVariable Long userId, @Valid @RequestBody Zone zone) {
		return zoneservice.addZone(userId, zone);
	}
	
	@GetMapping("getzone/{zoneId}")
	public Zone getZoneById(@PathVariable Long zoneId) {
	     return	zoneservice.getZoneByid(zoneId);
	}
	
	
	@PutMapping("/updateZone/{zoneId}")
    public Zone updateZone(@PathVariable Long zoneId,
    								
    								@Valid @RequestBody Zone ZoneUpdated) {
	 
		return zoneservice.updateZone(zoneId,ZoneUpdated);	    	
    	
    }
	
	@GetMapping("/deleteZone/{zoneId}")
	public String deleteZone(@PathVariable Long zoneId) {

		return zoneservice.deletesZone(zoneId);

	}

}
