package com.grokonez.jwtauthentication.model;

import java.io.Serializable;
import java.util.Date;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@Entity
@Table(name = "devices")
@JsonIgnoreProperties({ "hibernateLazyInitializer", "handler" })
public class Device implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;

	@Column(name = "nom")
	private String nom;

	@Column(name = "description")
	private String description;

	@Column(name = "date_ajout")
	private Date date_ajout;

	@Column(name = "date_modif")
	private Date date_modif;

	@Column(name = "type_device")
	private String type_device;

	@Column(name = "userid")
	private Long userid;

	@Column(name = "sapce_name")
	private String sapce_name;

	@ManyToOne(fetch = FetchType.LAZY, optional = false)
	@JoinColumn(name = "espace_id", nullable = false)
	@JsonIgnore
	private Espace espace;

	public Device() {
	}

	
	
	
	public Device(Long id, String nom, String description, Date date_ajout, Date date_modif, String type_device,
			Long userid, String sapce_name, Espace espace) {
		super();
		this.id = id;
		this.nom = nom;
		this.description = description;
		this.date_ajout = date_ajout;
		this.date_modif = date_modif;
		this.type_device = type_device;
		this.userid = userid;
		this.sapce_name = sapce_name;
		this.espace = espace;
	}




	public String getNom() {
		return nom;
	}

	public String getSapce_name() {
		return sapce_name;
	}

	public void setSapce_name(String sapce_name) {
		this.sapce_name = sapce_name;
	}

	public void setNom(String nom) {
		this.nom = nom;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public Date getDate_ajout() {
		return date_ajout;
	}

	public void setDate_ajout(Date date_ajout) {
		this.date_ajout = date_ajout;
	}

	public Date getDate_modif() {
		return date_modif;
	}

	public void setDate_modif(Date date_modif) {
		this.date_modif = date_modif;
	}

	public String getType_device() {
		return type_device;
	}

	public void setType_device(String type_device) {
		this.type_device = type_device;
	}

	public Long getUserid() {
		return userid;
	}

	public void setUserid(Long userid) {
		this.userid = userid;
	}

	public Espace getEspace() {
		return espace;
	}

	public void setEspace(Espace espace) {
		this.espace = espace;
	}

}
