package com.grokonez.jwtauthentication.servcicesImpl;

import java.util.List;
import java.util.Optional;
import java.util.Set;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PathVariable;

import com.grokonez.jwtauthentication.model.Espace;
import com.grokonez.jwtauthentication.model.NotFoundException;
import com.grokonez.jwtauthentication.model.Zone;
import com.grokonez.jwtauthentication.repository.EspaceRepository;
import com.grokonez.jwtauthentication.repository.ZoneRepository;
import com.grokonez.jwtauthentication.servcices.IEspaceService;

@Service("espaceService")
public class EspaceServiceImpl implements IEspaceService {
	
	
	@Autowired
	private ZoneRepository zoneRepository;
	
	@Autowired
	private EspaceRepository espaceRepository;

	@Override
	public Espace addEspace(Long zoneId, Espace espace) {
		return zoneRepository.findById(zoneId).map(zone -> {
			espace.setZone(zone);
			espace.setZonename(zone.getNom());
            return espaceRepository.save(espace);
        }).orElseThrow(() -> new NotFoundException("zone not found!"));
	}

	@Override
	public List<Espace> getListespacebyUser(Long userId) {
		
		return espaceRepository.findByUserid(userId);
	}

	@Override
	public Set<Espace> getListEspacebyZoneId(Long zoneId) {
		
		Optional<Zone> optZone = zoneRepository.findById(zoneId);
		if(optZone.isPresent()) {
    		Zone z = optZone.get();
    		return z.getEspaces();
    	}else {
    		throw new NotFoundException("zone not found with id " + zoneId);
    	}
	}

	@Override
	public String deletespace( Long espaceId) {
		
		Optional<Espace> optspace = espaceRepository.findById(espaceId);
		if(optspace.isPresent()) 
		{
			Espace a = optspace.get();
        	espaceRepository.delete(a);
        	return "200";
        	
			
		}
		else return "500";
		

    	
//        return espaceRepository.findById(espaceId)
//                .map(espace -> {
//                	espaceRepository.delete(espace);
//                    return "Deleted Successfully!";
//                }).orElseThrow(() -> new NotFoundException("Not found!"));
    }

	@Override
	public Espace updateEspace(Long espaceId, @Valid Espace espaceUpdated) {
		  return espaceRepository.findById(espaceId)
	                .map(espace -> {
	                  espace.setNom(espaceUpdated.getNom());
	                  espace.setDescription(espaceUpdated.getDescription());
	                  espace.setDate_modif(espaceUpdated.getDate_modif());
	                    return espaceRepository.save(espace);
	                }).orElseThrow(() -> new NotFoundException("espace  not found!"));
	}

	@Override
	public Espace getEspaceById(Long espaceId) {
		Optional<Espace> optSpace = espaceRepository.findById(espaceId);
    	if(optSpace.isPresent()) {
    		return optSpace.get();
    	}else {
    		throw new NotFoundException("Space not found with id " + espaceId);
    	}
	}

	@Override
	public Long getnbrEspace( Long userid) {
		return espaceRepository.getcountspaces(userid);
	}
		
	
	
	
	 

}
